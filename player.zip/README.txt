A Pen created at CodePen.io. You can find this one at http://codepen.io/ivanodintsov/pen/WRjXdy.

 Works best in Chrome and Safari.
It is not my design. If you know that designer please write his contacts and I will mention it.